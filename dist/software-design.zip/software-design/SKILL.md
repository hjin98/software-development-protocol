---
name: software-design
description: Diagnose and design nontrivial software changes, choose the simplest sufficient architecture, freeze only material requirements, and independently review completed substantial work for correctness, maintainability, and unnecessary complexity.
---

# Software Design

Use this role when a change needs real design work or when substantial/high-risk implementation deserves an independent review.

## Governing rule

**Materiality decides what must be accomplished. Simplicity decides how it should be accomplished.**

Among approaches that satisfy the same material requirements, prefer the one with fewer components, states, abstractions, interfaces, dependencies, special cases, and operational steps.

Complexity requires a concrete justification. Simplicity does not.

## Diagnose before designing

Inspect progressively from the reported behavior into the owning code and contracts. Identify the earliest violated invariant or structural limitation rather than designing around the final symptom.

Do not repeat repository-wide reconnaissance when focused evidence answers the question.

## Choose the design

Freeze only decisions implementation must not invent, such as:

- material algorithm/API/scientific/data semantics;
- ownership and authoritative state;
- persistence/recovery/compatibility contracts when material;
- performance/resource/security requirements when material;
- observable acceptance requirements;
- true non-goals and redesign triggers.

Prefer direct data/control flow, one authoritative state, small interfaces, and reuse of existing coherent mechanisms.

Do not create abstractions for hypothetical reuse, duplicate state for convenience, or add wrappers/fallbacks/supervisors merely to avoid reconsidering a failing mechanism.

A more complex design is appropriate only when the simpler design cannot satisfy a material requirement or risk.

## Redesign versus local fix

A local defect with a clear local cause should receive a small clean fix.

Reconsider the design when repeated failures occur in the same mechanism, fixes keep adding branches/wrappers/state, ownership is unclear, tests must reconstruct the product internally, or the implementation can no longer be explained coherently.

Prefer one clean redesign over a growing chain of hot fixes.

## Workplans

Use `templates/implementation_workplan_template.md` only when substantial reasoning, cross-module sequencing, public/persisted/scientific semantics, or expensive execution would otherwise be rediscovered.

Keep the workplan short. Gates are optional.

## Independent review mode

For substantial or high-risk completed work, review the actual diff/behavior against the material requirements. Look especially for:

- unnecessary mechanisms or duplicated paths;
- new failure points or state ownership ambiguity;
- short-term patches where simplification/refactoring would be safer;
- tests that validate a parallel harness instead of the real implementation;
- stale code or scaffolding that should now be removed;
- unsupported correctness, scientific, recovery, security, or performance claims.

Recommend acceptance, implementation correction, or redesign based on material engineering risk. Do not create ceremony merely to document the review.
