# Architecture and Design

## Purpose

Architecture describes the accepted current structure of the software. Proposed transitions belong in a workplan when a workplan is useful; implementation history does not belong in the architecture manual.

## Minimum Mechanism Principle

Choose the simplest design that satisfies the material requirements.

Complexity is an engineering liability because each component, state, interface, dependency, fallback, and special case creates another place for misunderstanding or failure. Additional mechanism is justified only by a concrete capability or risk the simpler design cannot satisfy.

Necessary complexity is allowed; accidental complexity is not.

## Design review

For a nontrivial feature, algorithm, persistence model, concurrency design, or structural refactor, establish only what is needed to implement correctly:

1. problem/root cause and scope;
2. material invariants and conventions;
3. authoritative state, ownership, and dependency direction;
4. simplest sufficient data/control flow and algorithm;
5. failure/recovery/compatibility behavior when material;
6. performance/resource/security constraints when material;
7. observable acceptance requirements and true non-goals.

Discuss alternatives only when more than one materially plausible design exists. Do not create an alternatives matrix for obvious local choices.

## Clean architecture

Prefer:

- one authoritative state rather than synchronized duplicates;
- direct dependency direction;
- cohesive components with clear ownership;
- small stable interfaces;
- standard/project-native mechanisms over custom frameworks;
- deletion of obsolete paths after migration;
- refactoring the owning layer rather than compensating in callers.

Do not split simple logic into many layers merely to appear modular. Abstraction is useful when responsibilities or invariants genuinely differ.

## Complexity warning signs

Reconsider the design when:

- repeated defects occur in the same mechanism;
- each fix adds another wrapper, fallback, retry, adapter, or compatibility path;
- multiple forms of the same state must remain synchronized;
- tests need to reconstruct or reimplement large parts of the product;
- control flow becomes difficult to explain succinctly;
- cleanup/removal is continually deferred;
- process/tooling code grows faster than the product capability it supports.

Do not stabilize bad architecture with more architecture.

## Local fix versus redesign

Use a small local fix for a small local defect.

Refactor or redesign when the clean local fix does not exist, the next patch materially worsens structure, or the mechanism has accumulated enough exceptional behavior that ownership and correctness are no longer clear.

## Design convergence

Stop designing when the material invariants, ownership, interfaces, algorithm, and acceptance evidence are clear enough to implement safely.

Do not continue hardening through speculative abstractions or cosmetic revisions.

## Current versus proposed architecture

```text
accepted current architecture -> architecture manual
proposed material transition   -> optional implementation workplan
accepted transition            -> update architecture manual
chronology                      -> history/release notes
```

Permanent architecture documentation should describe durable current behavior, not gates, temporary benchmark plans, unresolved checklists, or implementation chronology.
