---
kind: implementation-workplan
workplan_id: REPLACE_ME
protocol_version: 4.0.0
---

# <Task> Implementation Workplan

## Objective

<One concise outcome.>

## Diagnosis

<Root cause or current limitation.>

## Design

<The simplest sufficient approach, important ownership/invariants, and material non-goals.>

## Acceptance

- A1. <Observable material requirement.>
- A2. ...

## Implementation sequence

<Only include ordered steps/gates when ordering materially matters.>

## Risks / redesign triggers

<Only material risks or conditions that would require a different design.>
