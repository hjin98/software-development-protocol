# Testing and Validation

## Purpose

Testing answers engineering questions. Use the directest evidence that establishes the material requirement and stop when the question is answered.

## Three levels

1. **Focused** — unit, regression, property, boundary, or numerical-invariant check for the mechanism.
2. **Integrated** — exercise the affected consumer, persistence/recovery transition, package/install path, or other real interaction.
3. **Real use** — representative or production execution in the target environment when lower levels cannot establish the material claim or scale/environment is itself the claim.

Not every change needs every level.

## Test the product, not a parallel implementation

Prefer exercising production interfaces and real code paths.

A test harness should not substantially reimplement the algorithm, reconstruct a large private copy of production state, or create a second orchestration system merely to certify the first. If a mechanism is difficult to test directly, expose a smaller clean seam in the product rather than duplicating it in qualification code.

Synthetic fixtures are appropriate when they isolate the same mechanism cheaply and faithfully.

## Stop condition

Stop adding tests, repetitions, or scaling points once the material acceptance question is established with adequate confidence. Add more only when they could change the decision or protect an important regression boundary.

## Broad regression

Run the full suite when repository/release policy requires it or when the change has broad enough impact to justify it. Attribute unrelated pre-existing failures instead of constructing elaborate historical baselines solely to obtain a synthetic all-green result.

## Real-data and scientific validation

When material, use representative real data and define exact equality or justified tolerances. Check the final scientific observables and invariants that matter, not only internal kernels.

Do not weaken fidelity merely to make a test easier.

## Persistence and recovery

Test the state transitions that are actually risky: incompatible/corrupt state, interrupted publication, restart, migration/rejection, and equivalence with uninterrupted execution when those contracts changed.

Do not replay an entire production campaign when a smaller direct state-transition test establishes the same recovery contract.

## Performance

Correctness comes first. Measure performance under representative conditions and include setup/I/O/memory only when they materially affect the claim.

Reuse trustworthy existing baselines. If a relative baseline is unavailable, report absolute performance instead of manufacturing an elaborate counterfactual.

## Resource safety

Honor explicit CPU, RAM, VRAM, disk, and time constraints. Do not launch obviously unsafe work.

Use smaller representative workloads when they answer the same question. Use production scale when production scale is what must be demonstrated.

Hard limits may protect the host, but they are containment rather than a target. Do not respond to an oversized test by surrounding it with an increasingly elaborate resource-management framework; simplify the test or the product path first.

## Evidence

Normal test output, logs, measurements, and the candidate commit are usually sufficient. Record additional dataset/config/backend/hardware identity only when it changes interpretation.

Do not create evidence capsules, hash chains, special report schemas, or qualification-owned checkpoints unless the project has a real need for them.
