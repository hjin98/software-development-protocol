# Release and Distribution Validation

Source-tree correctness is not installed-artifact correctness. Use these checks only when a task actually ships or changes a package, build system, entry point, generated artifact, or release process.

## Build and inspect

As applicable:

- build the supported artifact;
- inspect expected modules/resources/entry points/package data;
- exclude secrets, caches, accidental datasets, local paths, and developer scratch;
- verify package/version metadata when it is part of the release contract.

## Isolated install

Install the produced artifact into a clean/isolated target and exercise the user-facing behavior outside the source checkout when installed behavior is material.

## Platforms and dependencies

Validate supported platform/backend combinations proportionally to release scope. Do not construct a combinatorial matrix that the project does not actually support or need.

## Reproducibility

The source commit is normally sufficient identity. Record exact artifact hashes only when exact built bytes matter.

Do not create report/hash chains merely for completeness.

## Hard rules

- Do not infer installed-artifact behavior solely from source-tree tests when packaging changed.
- Do not publish accidental secrets/data/scratch.
- Treat wrong package/version metadata as blocking only when it is part of the release contract.
