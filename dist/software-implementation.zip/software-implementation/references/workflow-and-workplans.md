# Workflow and Workplans

## Purpose

The workflow exists to help produce correct, maintainable software. It must not become a second product.

Protocol 4 has two roles:

```text
software-design -> software-implementation
```

`software-design` may also perform an independent final review when substantial or high-risk work benefits from fresh scrutiny.

## Default lifecycle

Use the shortest lifecycle that answers the engineering question.

### Small/local change

```text
inspect -> implement -> relevant test -> done
```

### Substantial change

```text
diagnose/design -> implement/refactor -> affected tests/real-use check -> review
```

### External or production execution

```text
design if needed -> implement -> run the actual program in the required environment -> inspect result
```

Crossing a machine or environment boundary does not by itself require a new role, handoff, supervisor, or report format. Record the command and material conditions when that is sufficient.

## Minimum Mechanism Principle

Every process step, artifact, helper, gate, retry loop, state machine, and automation layer adds failure and maintenance surface.

Add one only when it prevents a material failure or substantially reduces repeated work. If a simple command, direct test, or existing project mechanism solves the same problem, use it.

Do not build a parallel qualification system around the software merely to prove that the software works.

## Workplans

Use a workplan only when it prevents material design, scope, acceptance, or sequencing from being rediscovered.

A useful workplan contains only:

- objective;
- diagnosis;
- design and important invariants;
- observable acceptance requirements;
- implementation sequence when ordering matters;
- material risks/redesign triggers.

Do not require a workplan for routine local work.

## Gates

Gates are optional. Use them when crossing a boundary has a real reason, for example an irreversible migration, architecture approval before a broad rewrite, or an expensive run that depends on an earlier result.

Do not create G0/G1/G2/... simply because the protocol supports staging.

## Independent review

Fresh review is useful for substantial architecture, scientific/numerical semantics, persistence/recovery, security, release-critical behavior, or large risky refactors.

Review the implementation and evidence directly. Do not require a separate verification subsystem or formal report unless project policy does.

## Failure routing

Use a simple rule:

```text
failure -> find owning cause
        -> clean local fix? yes: fix/test
        -> no: refactor or redesign the owning mechanism
```

Repeated wrappers, fallbacks, compatibility shims, duplicated state, or test-only reconstructions are signals to simplify rather than continue patch accumulation.

## Process growth rule

A new mandatory protocol mechanism must identify the concrete engineering failure it prevents and why an existing simpler mechanism cannot prevent it.

If the main benefit is richer provenance, diagnostics, or process neatness, keep it optional.
