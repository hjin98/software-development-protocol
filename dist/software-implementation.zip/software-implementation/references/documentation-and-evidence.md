# Engineering Documentation and Evidence

## Purpose

Documentation should clarify durable contracts and decisions. Evidence should show what materially happened. Neither should become a parallel acceptance system.

## Document roles

Use only the artifacts the project actually needs:

- **Architecture** — accepted current structure, ownership, invariants, and material boundaries.
- **Specification** — accepted public/data/configuration/persistence/numerical contracts.
- **Implementation workplan** — temporary design/sequence record for substantial work when useful.
- **History/release notes** — chronology of completed user/release-significant changes.
- **User/API/runbook documentation** — stable use and operation guidance.
- **Evidence/logs** — executed checks and observed results when worth retaining.

Do not create separate qualification/verification documents merely because the development protocol has phases; Protocol 4 does not have those phases.

## Keep one source of truth

Maintain one normative owner for each current contract. Link rather than duplicate.

Update specifications when material public/persisted/scientific behavior changes. Update architecture when accepted architecture actually changes. Do not write temporary gates or implementation chronology into permanent manuals.

## Evidence

Normal test output, logs, benchmark measurements, and the candidate commit are usually enough.

Record additional input/config/backend/hardware identity only when it changes interpretation. For scientific work, retain material model/data/precision/oracle conditions. For performance, retain material workload and hardware/resource conditions.

Do not require workplan hashes, evidence-file hashes, timestamps, report schemas, provenance manifests, or structured capsules unless they protect a real release/compliance/content boundary.

## Generated documentation

Prefer editable source formats. Generate PDFs or other derived documents only when the project actually ships or requires them.

Do not create generators and provenance machinery solely to satisfy the protocol.

## Closeout

Before accepting substantial work, as applicable:

1. ensure specified contracts match implemented behavior;
2. update architecture only for real architectural change;
3. update user/release/version material required by repository policy;
4. ensure material tests/results are understandable;
5. delete temporary coordination artifacts that no longer serve a purpose.
