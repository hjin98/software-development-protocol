# Specification-Driven Implementation

## When a specification is needed

Create or update a specification when changing a contract consumers or persisted data rely on, such as public API/CLI/configuration behavior, file/schema/checkpoint semantics, numerical conventions, compatibility, or durable error/fallback behavior.

Do not create specifications for ordinary internal details.

## Specification content

Record the minimum stable information consumers need: purpose/scope, inputs/outputs, units/types/shapes where material, deterministic/error/fallback behavior, persistence/compatibility semantics, and examples or acceptance criteria when useful.

Current specifications describe accepted behavior. Proposed changes may live in a workplan until accepted.

## Implementation structure

Factor by real responsibility and invariant boundaries. Do not split simple logic into many modules/classes merely to appear modular.

Prefer existing project abstractions and standard mechanisms. Add a new abstraction when it removes duplication, isolates a genuine responsibility, or protects a material contract—not for hypothetical reuse.

## Persistence compatibility

For durable authoritative artifacts, define read/migrate/reject behavior when version evolution matters. For derived state, prefer invalidation/rebuild when it is simpler and safe.

## Input and error handling

Normalize at boundaries when useful, validate semantic constraints, raise actionable errors, and reject unsupported states when silent fallback would corrupt semantics.

Do not add fallback paths merely to hide a broken contract.

## Specification-code alignment

Before accepting a contract-changing implementation, compare actual behavior with the specification, update affected callers/tests/docs, and revise design if implementation materially diverged.

Specification-code parity matters when the specification governs a real contract. Administrative evidence completeness does not.
