# Protocol Versioning and Compatibility

## Protocol version

`PROTOCOL_VERSION` identifies the protocol contract.

- major: incompatible role/lifecycle authority change;
- minor: backward-compatible capability or doctrine addition;
- patch: clarification or defect correction.

Protocol 4.0 changes the lifecycle from four roles to two, so it is a major version.

## Protocol 4 roles

```text
software-design
software-implementation
```

Testing/target-environment validation is part of implementation. Independent final review, when useful, is performed through `software-design` rather than a separate verification role.

## Candidate identity

For a normal Git repository, the candidate commit plus absence of unintended product-defining working-tree changes is sufficient source identity.

Use extra hashes/manifests only at real boundaries not already identified by Git, such as external datasets, model weights, mutable production snapshots, source archives, or exact release artifacts.

Do not duplicate Git identity as paperwork.

## Workplan revisions

Revise a workplan when material target design, acceptance requirements, scope, or execution conditions change. Do not create revisions for command/path/report wording or other operational corrections.

## Evidence reuse

Rerun a check when a changed dimension could plausibly alter its result or interpretation. Do not rerun because only documentation, evidence location, or advisory metadata changed.

## Protocol 3 compatibility

Protocol 3 used `software-design`, `software-implementation`, `software-qualification`, and `software-verification` plus optional qualification handoffs and resource-bounded qualification machinery.

Completed Protocol 3 records remain historical evidence and do not need rewriting.

Active work may migrate to Protocol 4 by retaining the material design/acceptance requirements and dropping lifecycle artifacts that no longer protect a material boundary.

Do not reproduce removed Protocol 3 machinery merely for compatibility with its process shape.
