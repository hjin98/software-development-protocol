# Debugging and Stateful Recovery

## Diagnose before patching

For a nontrivial failure:

1. reproduce the smallest trustworthy failure;
2. follow the real execution path to the owning layer;
3. identify the earliest violated invariant or invalid state;
4. distinguish product logic, data/configuration, persisted state, dependency/environment, resource, I/O, and concurrency causes as needed;
5. fix the owner, not merely the final symptom;
6. add the smallest regression evidence that captures the mechanism.

Do not classify a failure from the exception name alone.

## Simplify before adding recovery machinery

When a mechanism repeatedly fails, ask whether state, caching, recovery, or orchestration can be removed or consolidated before adding another layer.

Derived/recomputable state often should be invalidated and rebuilt rather than migrated through elaborate compatibility machinery. Use journals/checkpoints/state machines only when the cost or correctness requirements justify them.

Do not add supervisors, repair passes, shadow state, retries, or compatibility shims merely to keep an unnecessarily complicated design alive.

## State identity

Persisted state that may be reused must be bound to the material inputs and semantics that determine its validity. Record only the identity necessary to reject or migrate incompatible state.

Do not create redundant lineage digests when an existing stable identifier already protects the boundary.

## Stateful stage design

When persistent recovery is genuinely required:

- make ownership and completion unambiguous;
- distinguish complete from partial/corrupt/stale state;
- publish completion after required outputs are valid;
- make restart/retry bounded and semantically safe;
- avoid duplicated authoritative state.

Keep the recovery model proportional to the cost of recomputation and the risk of loss.

## Production failure workflow

When a real input exposes a bug:

1. preserve enough evidence to understand it;
2. reduce the reproduction when useful;
3. identify the general invariant;
4. make the clean owning-layer fix or redesign;
5. run focused and affected integration checks;
6. rerun the real workflow when that provides material evidence;
7. remove obsolete workaround/scaffolding exposed by the fix.

## Anti-patterns

- changing expected values merely to make a test pass;
- broad exception swallowing with partial/stale output;
- deleting caches until the symptom disappears without finding the invalidation defect;
- indefinite retry of OOM/I/O failures;
- using file existence as proof of successful completion;
- stacking wrappers/fallbacks/repair layers around the same failing design;
- building a test-only reconstruction of a production state machine when the production interface can be exercised directly.

## Completion

Report the root cause, owning fix/redesign, regression evidence, affected persisted-state behavior, checks actually run, and any material environment not exercised. Keep the record proportional to the problem.
