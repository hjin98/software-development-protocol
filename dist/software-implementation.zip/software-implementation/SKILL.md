---
name: software-implementation
description: Implement, refactor, test, and validate software changes using the simplest sufficient mechanism. Prefer clean architecture and direct product-path evidence; fix local defects cleanly and return to design when fixes would accumulate complexity or change material semantics.
---

# Software Implementation

Use this role to make the software work correctly and keep the codebase easier, not harder, to maintain.

## Governing rule

**Materiality decides what must be accomplished. Simplicity decides how it should be accomplished.**

Implement the least mechanism that satisfies the material requirements. Do not add classes, helpers, states, caches, wrappers, fallbacks, compatibility layers, or orchestration merely because they appear sophisticated or might be useful later.

Prefer deletion and consolidation when they remove obsolete or duplicated behavior.

## Preflight

Read the governing workplan when one exists. Otherwise inspect the target path and its contracts directly.

Confirm the proposed change still addresses the owning cause. If implementation reveals that the design itself must materially change, return to `software-design` rather than silently growing a workaround.

## Implement cleanly

Prefer:

- one authoritative state;
- direct control/data flow;
- small cohesive functions and modules;
- existing project conventions;
- standard library or established dependency features over custom machinery;
- refactoring the owning layer over patching symptoms in callers;
- removing superseded code when the replacement is accepted.

Do not split one simple operation into many abstractions without a real responsibility boundary. Do not preserve obsolete paths merely because they already exist.

## Testing and validation

Use the most direct check that answers the material question:

1. focused unit/regression/property check for the mechanism;
2. affected integration/consumer path when needed;
3. representative or real production/target-environment execution when that is what establishes the requirement.

Stop when the material question is answered with adequate confidence.

A test harness should not substantially reimplement the product path it is meant to test. If testing requires reconstructing production internals, prefer testing through the production interface or exposing a smaller clean test seam.

Do not fabricate unavailable workstation/HPC/GPU/production results.

## Resource safety

Do not exhaust the machine. Honor explicit CPU/RAM/VRAM/disk/time limits and use a smaller representative workload when it proves the same claim. Use full production scale when scale itself is material.

Hard containment is appropriate for genuinely risky execution, but do not build a generic supervisor/calibration/admission/recovery framework unless the product or test genuinely needs one.

## Failure handling

When a failure appears:

1. locate the owning cause;
2. fix it locally if a clean local fix exists;
3. add the smallest regression evidence that protects the mechanism;
4. remove obsolete workaround/scaffolding exposed by the fix;
5. return to design when the next fix would add another layer, duplicate state/pathways, or materially change the target.

Repeated complexity growth is evidence to refactor or redesign, not a reason to add more machinery.

## Completion

Report what changed, what material checks actually ran, any real environment not exercised, and any remaining material risk. Do not manufacture handoffs, evidence capsules, or extra lifecycle stages when normal code/tests/logs already establish the result.
