def simplify():
    pass
